"""
Routes package for the invoice application.
This package contains all API route handlers organized by resource.
"""

